// import 'package:elogger/elogger.dart';

// void main() {
//   var awesome = Awesome();
//   print('awesome: ${awesome.isAwesome}');
// }
