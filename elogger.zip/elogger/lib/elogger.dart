/// Support for doing something awesome.
///
/// More dartdocs go here.
library elogger;

export 'src/elogger_base.dart';

// TODO: Export any libraries intended for clients of this package.
