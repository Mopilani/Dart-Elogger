import 'dart:io';

class Elogger {
  Elogger.init(this._logger,
      {this.printLogs = false,
      this.saveLogsToFile = false,
      this.lineNumber = 1,
      this.startTime}) {
    if (_logger == null) {
      throw 'logger Name is null, try definging a logger name';
    }
    loggerName = _logger;
    _EloggerPersistentCache.set('logger', _logger);
    _EloggerPersistentCache.set('printLogs', printLogs);
    _EloggerPersistentCache.set('saveLogsToFile', saveLogsToFile);
    _EloggerPersistentCache.set('line', lineNumber);
    startTime ??=
        '${DateTime.now().year}-${DateTime.now().month}-${DateTime.now().day}-${DateTime.now().hour}-${DateTime.now().minute}-${DateTime.now().second}-${DateTime.now().millisecond}';
    _EloggerPersistentCache.set('startTime', startTime);
    if (_logger != null) {
      loggerDefaultName = _logger;
    }
    // print(loggerDefaultName);
    loggerDefaultFileName = '$_logger-$startTime.elog';
  }

  factory Elogger() {
    if (_EloggerPersistentCache.get('logger') != null) {
      if (_EloggerPersistentCache.get('printLogs') != null) {
        if (_EloggerPersistentCache.get('saveLogsToFile') != null) {
          if (_EloggerPersistentCache.get('startTime') != null) {
            return Elogger.init(
              _EloggerPersistentCache.get('logger'),
              printLogs: _EloggerPersistentCache.get('printLogs'),
              saveLogsToFile: _EloggerPersistentCache.get('saveLogsToFile'),
              lineNumber: _EloggerPersistentCache.get('line'),
              startTime: _EloggerPersistentCache.get('startTime'),
            );
          }
        }
      }
    } else {
      throw 'No exist logger found, try define logger';
    }
    return Elogger.init('Elogger');
  }

  // Elogger._();

  String? _logger;
  bool? printLogs, saveLogsToFile;
  String? loggerDefaultName = 'Elogger';
  int? lineNumber;
  String? startTime = DateTime.now().toString();
  List<dynamic> get logList => _log;

  set logList(newLine) {
    _log.add(newLine);
    _EloggerPersistentCache.set('log', _log);
  }

  set loggerName(logger) => _logger = logger;

  String get loggerName {
    if (_EloggerPersistentCache.get('logger') != null) {
      return _EloggerPersistentCache.get('logger');
    }
    return 'Elogger';
  }

  // ignore: prefer_final_fields
  List<dynamic> _log = [];

  String? loggerDefaultFileName;

  // ignore: always_declare_return_types
  static log(Object text,
      {bool err = false,
      @Deprecated('Use scss for cut') bool success = false,
      bool scss = false}) {
    /// if "success" value is not true it mean the "scss" value is assaigned
    if (!success) {
      success = scss;
    }

    /// if the `printLog` is enabled will call the print log function
    if (_EloggerPersistentCache.get('printLogs') != null) {
      if (_EloggerPersistentCache.get('printLogs')) {
        Elogger.init(
          _EloggerPersistentCache.get('logger'),
          printLogs: _EloggerPersistentCache.get('printLogs'),
          saveLogsToFile: _EloggerPersistentCache.get('saveLogsToFile'),
          lineNumber: _EloggerPersistentCache.get('line'),
          startTime: _EloggerPersistentCache.get('startTime'),
        ).printAsLogger(text.toString(), err: err, success: success);
        // ..logList = text;
      }
    }
    if (_EloggerPersistentCache.get('saveLogsToFile') != null) {
      if (_EloggerPersistentCache.get('saveLogsToFile')) {
        Elogger.init(
          _EloggerPersistentCache.get('logger'),
          printLogs: _EloggerPersistentCache.get('printLogs'),
          saveLogsToFile: _EloggerPersistentCache.get('saveLogsToFile'),
          lineNumber: _EloggerPersistentCache.get('line'),
          startTime: _EloggerPersistentCache.get('startTime'),
        ).recordToFile(text.toString());
      }
    }
  }

  void recordToFile(String contents) {
    var dir = Directory('elogs');
    if (!dir.existsSync()) {
      dir.create().then((directory) {
        var file = File('${directory.path}/$loggerDefaultFileName');
        file.writeAsStringSync('\n$lineNumber: $contents',
            mode: FileMode.append);
        _EloggerPersistentCache.set('line', lineNumber! + 1);
      });
    } else {
      var file = File('${dir.path}/$loggerDefaultFileName');
      file.writeAsStringSync('\n$lineNumber: $contents', mode: FileMode.append);
      _EloggerPersistentCache.set('line', lineNumber! + 1);
    }
  }

  int logFileNumber = 1;

  Future saveAllLog({LogType logType = LogType.byTime}) async {
    var dir = Directory.current.path;
    if (logType == LogType.byTimes) {
      try {
        var file = File('$dir/$loggerDefaultFileName');
        await file.exists().then(
          (value) async {
            if (value) {
              for (var i = 0; i < 10; i++) {
                print("Retry to rename the log file becase it's found");
                if (await File('').exists()) {
                  break;
                } else {
                  logFileNumber++;
                }
              }
            } else {
              loggerDefaultFileName = '$_logger.elog';
            }
          },
        );
        file.openWrite();
      } catch (e) {
        printAsLogger(e.toString(), err: true);
      }
    } else if (logType == LogType.byTime) {
      try {
        var file = File('$dir/$loggerDefaultFileName');
        await file.exists().then(
          (value) async {
            if (value) {
              for (var i = 0; i < 10; i++) {
                print("Retry to rename the log file becase it's found");
                loggerDefaultFileName = '$_logger At ${DateTime.now()}.elog';
              }
            } else {
              loggerDefaultFileName = '$_logger At ${DateTime.now()}.elog';
            }
          },
        );
        file = File('$dir/$loggerDefaultFileName');
        for (var i = 0; i < _log.length; i++) {
          await file.writeAsString(_log[i], mode: FileMode.append);
        }
      } catch (e) {
        printAsLogger(e.toString(), err: true);
      }
    }
  }

  Future<void> programEnd(LogType logType) async {
    await saveAllLog(logType: logType);
  }

  void printAsLogger(String text, {bool err = false, bool success = false}) {
    var modfiedText = '';
    if (err) {
      print('--------[Error]-----------');
      print('$_logger: $text');
      print('^^^^^^^^^^^^^^^^^^^^^^^^^^');
    } else if (success) {
      print('$_logger: $text -[Success]-');
    } else {
      print('$_logger: $text');
    }
  }
}

enum LogType {
  byTime,
  byTimes,
  NoThing,
}

class _EloggerPersistentCache {
  static final Map<String, dynamic> _cache = <String, dynamic>{};

  static dynamic set(String key, dynamic value) => _cache[key] = value;

  static dynamic get(String key) => _cache[key];
}
